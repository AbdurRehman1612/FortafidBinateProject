// const express = require("express");
// const app = express();
// const cors = require("cors");
// const originURL = ["http://localhost:3000"];
// const bodyParser = require("body-parser");

// app.use(
//   cors({
//     origin: originURL,
//     credentials: true,
//   })
// );

// app.use(express.json({ limit: "50mb" }));
// app.use(express.urlencoded({ limit: "50mb", extended: true }));

// app.use("/routes/user/",require("./routes/user"))

// app.listen(5000, () => {
//   console.log("Server is running on port http://localhost:5000/");
// });

const express = require("express");
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require('path');
var fs = require('fs');
const dotenv = require("dotenv");
const db = require("./models")

const {
  get_messages,
  send_message
} = require('./utils/messages');


const options = {
    key: fs.readFileSync('/home/serverappsstagin/ssl/keys/c147a_3611f_6747a0f59bb7c85ec6cd18e67a6c9c59.key'),
    cert: fs.readFileSync('/home/serverappsstagin/ssl/certs/server_appsstaging_com_c147a_3611f_1673222399_383be20a7643b2bbd3b6a18edd6ff604.crt'),
};

 const server = require('https').createServer(options, app);
 
 const contentSeeder = [
  {
      title: "Privacy Policy",
      content: "Lorem ipsum dolor sit amet.Ea iste consectetur qui harum libero exercitationem harum et quam earum At cupiditate perferendis qui aspernatur vero!",
      content_type: "privacy_policy"
  },
  {
      title: "Terms and Conditions",
      content: "Lorem ipsum dolor sit amet.Ea iste consectetur qui harum libero exercitationem harum et quam earum At cupiditate perferendis qui aspernatur vero!",
      content_type: "terms_and_conditions"
  },
  {
      title: "Help and Support",
      content: "Lorem ipsum dolor sit amet.Ea iste consectetur qui harum libero exercitationem harum et quam earum At cupiditate perferendis qui aspernatur vero!",
      content_type: "help_and_support"
  }
];
const dbSeed = async () => {
  await db.TCandPP.deleteMany({});
  await db.TCandPP.insertMany(contentSeeder);
}
dbSeed().then(() => {
  // mongoose.connection.close();
})

var io = require('socket.io')(server, {
  cors: {
      origin: "*",
      methods: ["GET", "POST","PATCH","DELETE"],
      credentials: true,
      transports: ['websocket', 'polling'],
      allowEIO3: false
  },
});
io.on('connection', socket => {
console.log("socket connection " + socket.id);
socket.on('get_messages', function(object) {
    var user_room = "user_" + object.sender_id;
      socket.join(user_room);
      get_messages(object, function (response) { 
          if (response.length > 0) {
              console.log("get_messages has been successfully executed...");
              io.to(user_room).emit('response', { object_type: "get_messages", data: response });
          } else {
              console.log("get_messages has been failed...");
              io.to(user_room).emit('error', { object_type: "get_messages", message: "There is some problem in get_messages..." });
          }
      });
});
// SEND MESSAGE EMIT

socket.on('send_message', function(object) {
    var sender_room = "user_" + object.sender_id;
      var receiver_room = "user_" + object.receiver_id;
      send_message(object, async (response_obj)=> {
          if (response_obj) {
              console.log("send_message has been successfully executed...");
                io.to(sender_room).to(receiver_room).emit('response', { object_type: "get_message", data: response_obj }); 
        //         const nurse=await User.findOne({_id:object?.sender_id})
        //         if(nurse){    
        //       const notification_obj = {
        //     user_device_token: nurse?.user_device_token,
        //     sender_text: object?.message,
        //     heading: `new message from ${nurse?.name}`  
        //   }; 
        //  await push_notification(notification_obj);
        //         }
          } else {
              console.log("send_message has been failed...");
              io.to(sender_room).to(receiver_room).emit('error', { object_type: "get_message", message: "There is some problem in get_message..." });
          }
      });
});
});

app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.json());
dotenv.config();
app.use('/upload', express.static(path.join(__dirname, 'upload')))

// Router config
app.use("/routes/user/", require("./routes/user"));
app.use("/routes/therapist/", require("./routes/therapist"));
app.use("/routes/therapies/", require("./routes/therapies"));
app.use("/routes/business/", require("./routes/business"));
app.use("/routes/appointments/", require("./routes/appointments"));
app.use("/routes/chat/", require("./routes/chat"));
app.use("/routes/tcandpp/", require("./routes/tcandpp"));

const PORT = 3011 || process.env.PORT;

// app.listen(PORT, (req, res) => {
//   console.log(`Server running on ${PORT}`);
// });


server.listen(PORT, () => console.log('Server running on', PORT));
