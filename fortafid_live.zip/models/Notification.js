const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const notificationSchema = new Schema( {
      message: {
          type: String,
          
      },
      sender_text: {
        type: String,
        
    },
    
      is_blocked: {
         type: Number,
         default: 0
      },
      user_id: {
          type: String,
      },
      
    },
    {
      timestamps: true,
    });
module.exports = mongoose.model('Notification', notificationSchema);